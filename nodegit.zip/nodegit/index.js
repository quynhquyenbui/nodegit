const express = require('express')
const app = express()
const https = require('https');
const axios = require('axios');
const request = require('request');
var gitlab = require('gitlab')

app.set('view engine', 'ejs')

process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

app.get('/', async function (req, res) {

   await axios.get('https://gitlab.tamgr.com/api/v4/projects/3/merge_requests?state=merged&private_token=QFgg7fUdtmUj8km6Taxg')
  .then(response => {
    console.log(response);
    res.render('index', { data: response}) 
  })
  .catch(error => {
    console.log(error);
  });

 
  
})





app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})